<?php

/* @var $this yii\web\View */

$this->title = 'Archive Portal';
use yii\bootstrap\Html;
?>
<div class="site-index" >



    <p class="text-primary"><h1>Welcome to KCB archive Portal</h1></p>


</div>
